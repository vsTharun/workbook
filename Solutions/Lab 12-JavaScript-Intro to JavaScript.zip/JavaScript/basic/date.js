window.onload = initAll;

function initAll() {
	var now = new Date();
	
	
	
	
}
